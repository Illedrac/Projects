#include "GameController.h"

int WinMain()
{
    GameController gc;

    gc.StartGame();

    return 0;
}