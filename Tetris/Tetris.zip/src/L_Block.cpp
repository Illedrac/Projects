#include "L_Block.h"

L_Block::L_Block()
    : Block(BLOCK_TYPE::L)
{
    block_positions.push_back(std::make_pair(parent_start_row + 1, parent_start_col));
    block_positions.push_back(std::make_pair(parent_start_row + 2, parent_start_col));
    block_positions.push_back(std::make_pair(parent_start_row + 2, parent_start_col + 1));
}
/*
void L_Block::RotateBlock()
{
    previous_block_positions = block_positions;

    switch (rotation_state)
    {
        case 0:
        {
            block_positions.at(0) = (std::make_pair(previous_block_positions.at(0).first - 1, previous_block_positions.at(0).second - 1));
            //block_positions.at(1) = (std::make_pair(previous_block_positions.at(1).first, previous_block_positions.at(1).second));
            block_positions.at(2) = (std::make_pair(previous_block_positions.at(2).first + 1, previous_block_positions.at(2).second + 1));
            block_positions.at(3) = (std::make_pair(previous_block_positions.at(3).first, previous_block_positions.at(3).second + 2));
            break;
        }
        case 1:
        {
            break;
        }
        case 2:
        {
            break;
        }
        case 3:
        {
            break;
        }
    }

    rotation_state = (rotation_state + 1) % 4;
}*/