#pragma once
#include "Block.h"

class J_Block : public Block
{
public:
    J_Block();



};
