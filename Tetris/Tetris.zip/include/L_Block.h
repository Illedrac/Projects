#pragma once

#include "Block.h"

class L_Block : public Block
{
public:
    L_Block();


}; 