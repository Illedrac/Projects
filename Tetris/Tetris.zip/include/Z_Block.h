#pragma once
#include "Block.h"

class Z_Block : public Block
{
public:
    Z_Block();



};