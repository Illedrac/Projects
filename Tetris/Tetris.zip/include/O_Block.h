#pragma once
#include "Block.h"

class O_Block : public Block
{
public:
    O_Block();


}; 