#pragma once
#include "Block.h"

class I_Block : public Block
{
public:
    I_Block();


};
