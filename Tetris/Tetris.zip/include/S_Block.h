#pragma once

#include "Block.h"

class S_Block : public Block
{
public:
    S_Block();


}; 
