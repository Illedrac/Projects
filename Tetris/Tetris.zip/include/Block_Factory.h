#pragma once
#include "Block.h"

class Block_Factory
{
    

    
public:
    static Block* getBlock();
    
};